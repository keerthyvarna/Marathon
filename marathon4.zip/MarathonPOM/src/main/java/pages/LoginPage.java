package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import projectSpecificMethod.base;

public class LoginPage extends base {
	public LoginPage(ChromeDriver driver,ExtentTest test,ExtentReports extent  ) {
		this.driver=driver;
		this.test=test;
		this.extent=extent;
		
	}
	
	public LoginPage enterUsername() throws IOException {
		try {
		driver.findElement(By.id("username")).sendKeys("keerthyvarna06@gmail.com");
		reportStatus("pass","userName is entered successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "userName is not entered successfully");
	}
		
		return this;
	}
	
	public LoginPage enterPassword() throws IOException {
		try {
		driver.findElement(By.id("password")).sendKeys("Tester@0608");
		reportStatus("pass","password is entered successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "password is not entered successfully");
	}
		
		return this;
	}
	
	public HomePage clickLogin() throws IOException {
		try {
		driver.findElement(By.id("Login")).click();
		reportStatus("pass","Login is  successfull");
		}
	catch(Exception e) {
		reportStatus("fail", "Login is not  successfull");
	}
		return new HomePage(driver,test, extent);
	}
	
	


}
