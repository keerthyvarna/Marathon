package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import projectSpecificMethod.base;

public class IndividualsPage extends base {

	public IndividualsPage(ChromeDriver driver, ExtentTest test, ExtentReports extent) {
		this.driver=driver;
		this.test=test;
		this.extent=extent;
		
	}
	
	public IndividualsPage verifyIndividual() throws IOException {
		try {
		String message = driver.findElement(By.xpath("//span[@class='toastMessage slds-text-heading--small forceActionsText']")).getText();
		//verify Individuals Name
		String text = driver.findElement(By.xpath("//span[@class='uiOutputText']")).getText();
		if(text.equalsIgnoreCase("Muthukumar")) {
			System.out.println("name is verified");
		}
		else {
			System.out.println("name is not verified");
		}
		reportStatus("pass","Individual created successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "Individual is not created successfully");
	}
		return this;
	}

}
