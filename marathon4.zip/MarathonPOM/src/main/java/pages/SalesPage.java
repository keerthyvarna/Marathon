package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import projectSpecificMethod.base;

public class SalesPage extends base {

	public SalesPage(ChromeDriver driver, ExtentTest test, ExtentReports extent) {
		this.driver=driver;
		this.test=test;
		this.extent=extent;
		
	}
	
	public SalesPage searchName(String search) throws InterruptedException, IOException {
		try {
		WebElement name =driver.findElement(By.xpath("//input[@name='Individual-search-input']"));
		name.sendKeys(search);
		name.sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		reportStatus("pass","searched name successfullu");
		}
	catch(Exception e) {
		reportStatus("fail", "search name failed");
	}
		return this;
	}
	
	public SalesPage selectIndividual() throws InterruptedException, IOException {
		try {
		WebElement ele = driver.findElement(By.xpath("//div[@class='forceVirtualActionMarker forceVirtualAction']/a[@role='button']"));
		driver.executeScript("arguments[0].click();", ele);
		Thread.sleep(3000);
		reportStatus("pass","Individual is selected successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "Individual  is not selected successfully");
	}
		return this;
	}
	
		
	
	public SalesPage clickNewIndividual() throws IOException {
		try {
		driver.findElement(By.xpath("//div[@class='slds-context-bar__label-action slds-p-left--none slds-p-right--x-small']//a")).click();
		WebElement clk = driver.findElement(By.xpath("//span[text()='New Individual']"));
		driver.executeScript("arguments[0].click();", clk);
		reportStatus("pass","New Individual is clicked successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "New Individual is not clicked successfully");
	}
		return this;
	}
	
	public SalesPage enterLastName(String lname) throws IOException {
		try {
		driver.findElement(By.xpath("//input[contains(@class,'lastName compound')]")).sendKeys(lname);
		reportStatus("pass","last name is entered successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "last name is not entered successfully");
	}
		return this;
	}
	
	public IndividualsPage clickSave() throws IOException {
		try {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		reportStatus("pass","Individual is saved successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "individual is not saved successfully");
	}
		return new IndividualsPage(driver,test,extent);
	}
	public SalesPage clickEditSave() throws InterruptedException, IOException {
		try {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(2000);
		reportStatus("pass","saved successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "not saved");
	}
		return this;
	}
	public SalesPage clickEdit() throws IOException {
		try {
		WebElement edit = driver.findElement(By.xpath("//a[@title='Edit']/div"));
		driver.executeScript("arguments[0].click();", edit);
		reportStatus("pass","Edit is clicked successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "Edit is not clicked");
	}
	   return this;
	}
	
	public SalesPage clickSalutation() throws IOException {
		try {
		driver.findElement(By.xpath("//a[@class='select']")).click();
		driver.findElement(By.xpath("//a[text()='Ms.']")).click();
		reportStatus("pass","Salutation is set successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "Salutation is not set unsuccessfull");
	}
		return this;
	}
	
	public SalesPage clearFirstName() throws IOException {
		try {
		driver.findElement(By.xpath("//input[contains(@class,'firstName')]")).clear();
		reportStatus("pass","first name is cleared successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "first name  is not cleared unsuccessfull");
	}
		return this;
	}
	public SalesPage enterFirstName(String fname) throws IOException {
		try {
		driver.findElement(By.xpath("//input[contains(@class,'firstName')]")).sendKeys(fname);
		reportStatus("pass","first name is entered successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "first name is not entered successfully");
	}
		return this;
	}
	
	public SalesPage clickDelete() throws InterruptedException, IOException {
		try {
		WebElement delete = driver.findElement(By.xpath("//a[@role='menuitem']/div[@title='Delete']"));
		driver.executeScript("arguments[0].click();", delete);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Delete']")).click();
		reportStatus("pass","delete is clicked successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "delete is not clicked successfully");
	}
		return this;
	}
	
	public SalesPage verifyEdit() throws IOException {
		try {
		String msg = driver.findElement(By.xpath("//span[contains(@class,'toastMessage')]")).getText();
		   //Verify the first name as 'Ganesh'
			System.out.println(msg);
			reportStatus("pass","Edited successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "Edit is unsuccessfull");
	}
			return this;
	}
	
	public SalesPage verifyDelete() throws IOException {
		try {
		String msg = driver.findElement(By.xpath("//span[contains(@class,'toastMessage')]")).getText();
		 System.out.println(msg);
		driver.findElement(By.xpath("//input[@class='slds-input']")).sendKeys("Keerthana",Keys.ENTER);
	//	Thread.sleep(3000);
		String verify = driver.findElement(By.xpath("//span[text()='No items to display.']")).getText();
		//Verify Whether Individual is Deleted using Individual last name"
		System.out.println(verify);
		reportStatus("pass","deleted successfully");
		}
	catch(Exception e) {
		reportStatus("fail", "Delete is unsuccessfull");
	}
		return this;
	}

}
