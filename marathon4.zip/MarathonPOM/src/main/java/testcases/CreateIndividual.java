package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import projectSpecificMethod.base;

public class CreateIndividual extends base {
	
	@BeforeTest
	public void setFile() {
		filename="CreateIndividualData";
		testcaseName="CreateIndividual";
		testDesc="checking the functionality of salesforce";
		author="keerthana";
		category="Functional";
		 
		
	}
	
	@Test(dataProvider="myData")
	public  void runCreate(String lname) throws IOException {
		LoginPage ob = new LoginPage(driver,test, extent);
		ob.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickAppLauncher()
		.clickViewAll()
		.clickIndividuals()
		.clickNewIndividual()
		.enterLastName(lname)
		.clickSave()
		.verifyIndividual();
	}

}
