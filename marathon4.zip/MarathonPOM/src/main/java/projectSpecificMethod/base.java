package projectSpecificMethod;

import java.io.File;


import java.io.IOException;

//import static org.testng.Assert.ARRAY_MISMATCH_TEMPLATE;


import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadExcel;

//import utils.ReadExcel;





public class base {
	public  ChromeDriver driver;
	public  String filename;
	public   static ExtentReports extent;
	public  static ExtentTest test,node;

	public String testcaseName, testDesc, author, category;
	@BeforeMethod
	public void preCondition() {
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--disable-notifications");

	    driver = new ChromeDriver(option);
	    node = test.createNode(testcaseName);

		driver.get("https://login.salesforce.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	@AfterMethod
	public void postCondition(){
	    driver.close();
	}
	@DataProvider(name="myData")
	public String[][] testData() throws IOException {		
		return ReadExcel.readExcel(filename);	
		

}
	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		extent = new ExtentReports();
		reporter.setAppendExisting(true);
		extent.attachReporter(reporter);

	}		

	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testcaseName, testDesc);
		test.assignCategory(category);
		test.assignAuthor(author);
	}

	public void reportStatus(String status, String info) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			test.pass(info, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot"+takeSnap()+".png").build());

		} else if (status.equalsIgnoreCase("fail")) {
			test.fail(info, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot"+takeSnap()+".png").build());
			throw new RuntimeException("Check the testStep");
		}
	}	
	
	public int takeSnap() throws IOException {	
		int random =(int)(Math.random()*999999);
		File source = driver.getScreenshotAs(OutputType.FILE);
	    File destn=new File("./snap/shot"+random+".png");
	  FileUtils.copyFile(source, destn);
	  return random;
	}
	
	

	@AfterSuite
	public void endReport() {
		extent.flush();
	}

}


